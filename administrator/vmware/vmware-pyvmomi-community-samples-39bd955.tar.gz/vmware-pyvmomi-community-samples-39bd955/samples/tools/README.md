pyvmomi-community-samples samples.tools
=======================================

Any reusable classes or methods that you develop can be included in packages
under this directory. When adding a reusable component we highly recommend
that you include tests.

Only some samples will make use of reusable components. This is where to put
those.